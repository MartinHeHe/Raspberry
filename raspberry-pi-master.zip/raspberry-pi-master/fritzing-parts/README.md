Third-party Fritzing parts found from the Internet, I can't remember the original source & backup them here just for convenience & thanks to the authors.

****

从网上找到的第三方Fritzing组件，不记得原始出处了，存于此处仅为了便于参考，感谢原作者。
