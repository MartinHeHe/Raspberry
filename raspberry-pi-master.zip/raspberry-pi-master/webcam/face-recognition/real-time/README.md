# A real-time face-recognition demo based on Raspberry Pi.
The backend cloud service to provide face-recognition ability is provided by Face++(www.faceplusplus.com.cn).
