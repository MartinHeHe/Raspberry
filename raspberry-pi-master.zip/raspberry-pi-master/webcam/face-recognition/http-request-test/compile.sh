#!/bin/bash

g++ request.cpp -lcurl -o request
