Subprojects under this dir are artificial-intelligent related applications. They may be very simple, but tries to make Raspberry Pi more "clever".

这个目录下的子项目是和人工智能相关的一些应用。它们可能很简单，但是试图让树莓派变得更“聪明”。
