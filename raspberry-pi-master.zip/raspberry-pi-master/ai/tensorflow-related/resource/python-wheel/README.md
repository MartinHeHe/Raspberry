To start writing any TensorFlow code on Raspberry Pi, you should install it on Raspberry Pi through a Python wheel first. Refer to [this](https://github.com/samjabrahams/tensorflow-on-raspberry-pi) link or [this](http://www.codelast.com/?p=8941) link to find out how to do this.

在开始编写TensorFlow代码之前，你应该先在树莓派上，通过一个Python wheel包来安装TensorFlow，具体怎么做，请参考[这个链接](https://github.com/samjabrahams/tensorflow-on-raspberry-pi) 或者 [这个链接](http://www.codelast.com/?p=8941)。
