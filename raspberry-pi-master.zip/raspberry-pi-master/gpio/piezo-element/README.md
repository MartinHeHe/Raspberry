Demo on how to play music through a piezo element.

****

该目录下的程序演示了如何用树莓派驱动压电蜂鸣器播放音乐。
