For each Raspberry Pi model, you should combine the input & output part to one circuit diagram, for clarity reason I drawn them separately.

****

对每一种树莓派型号的电路图，应该把输入(input)以及输出(output)部分的电路图结合起来看（为了能表示清晰一些我才将它们分开绘制的）。
