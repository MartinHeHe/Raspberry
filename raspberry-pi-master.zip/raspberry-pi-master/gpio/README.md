Some applications based on RPi's GPIO ports.

****

该目录下是基于树莓派的GPIO接口开发的一些应用程序。每个子项目下均有单独的 README 说明文档，请点进去查看详情。
