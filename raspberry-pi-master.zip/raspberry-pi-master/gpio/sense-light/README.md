Demo on how to control some LEDs through an pyroelectric module.

****

该目录下的程序演示了如何通过一个热释电模块感应人体，从而控制一些LED的亮灭。
