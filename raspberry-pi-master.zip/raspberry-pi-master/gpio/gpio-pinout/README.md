Images under these dirs illustrate the GPIO pinout of some Raspberry Pi models, they are copied from http://pi4j.com/ website, just for convenience.

****

此目录下包含部分树莓派型号的GPIO引脚分布图，它们是从 http://pi4j.com/ 拷贝过来的，仅为了便于参考使用。
