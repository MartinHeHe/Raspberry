Demos on how to display some messages on a LCD1602 screen, including the examples of using/not using an PCF8574 I2C module.

****

该目录下的程序演示了如何用树莓派控制LCD1602液晶屏显示一些信息，其中包括 使用 以及 不使用 PCF8574 I2C模块的例子。

![](https://raw.githubusercontent.com/codelast/raspberry-pi/master/gpio/lcd/demo/lcd1602-8bit-display.png)
![](https://raw.githubusercontent.com/codelast/raspberry-pi/master/gpio/lcd/demo/lcd1602-with-i2c-2.jpg)
