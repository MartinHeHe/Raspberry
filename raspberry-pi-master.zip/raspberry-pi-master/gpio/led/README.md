Demos on how to:
* blink a LED
* control a LED through a button(pressed or not)
* control the brightness of a LED through PWM

****

该目录下的程序演示了：
* 如何用树莓派控制LED闪烁
* 如何通过一个外部按钮的开关来控制LED的亮灭
* 如何通过PWM来控制LED的亮度
