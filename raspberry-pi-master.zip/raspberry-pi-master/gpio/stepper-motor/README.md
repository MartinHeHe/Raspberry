Demos on how to control a stepper motor through the GPIO ports on Raspberry Pi.

****

该目录下的程序演示了如何通过树莓派的GPIO接口控制步进电机。

![](https://raw.githubusercontent.com/codelast/raspberry-pi/master/gpio/stepper-motor/demo/stepper-motor.png)
