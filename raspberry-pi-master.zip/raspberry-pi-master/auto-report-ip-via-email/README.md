Script & config files to let Raspberry Pi report its IP address to an specified Email address at system startup.

****

让树莓派开机的时候自动发送其IP地址到指定Email的一些脚本以及配置文件。
